ei = ["abstener", "abstenerse", "adherir", "adquirir", "advertir", "apretar", "arrepentir", "ascender", 
"asentir", "atender", "atravesar", "calentar", "cerrar", "circunvenir", "comenzar", "conferir", "confesar", 
"consentir", "contener", "contravenir", "convenir", "convertir", "defender", "descender", "desmembrar", 
"desmentir", "despertar", "desperarse", "desplegar", "detener", "diferir", "digerir", "discernir", "disentir", 
"divertirse", "empezar", "encender", "encerrar", "encomendar", "enmendar", "ensangrentar", "entender", "enterrar", 
"entretener", "entrevenir", "extender", "fregar", "gobernar", "heder", "helar", "herir", "hervir", "inferir",
"ingerir", "intervenir", "invernar", "invertir", "malherir,", "manifestar", "mantener", "mentar", "mentir", "mentirse", 
"merendar", "negar", "nevar", "obtener", "ofender", "pensar", "perder", "pervertir", "preferir", "presentir", "prevenir"
"querer", "recomendar", "referir", "regar", "remendar", "renegar", "replegar", "requerir", "restregar", "retener", 
"reventar", "segar", "sembrar", "sentar", "sentir", "sentirse", "serrar", "sosegar", "sostener", "soterrar",
"subarrender", "sugerir", "temblar", "tender", "tener", "tentar", "transferir", "tropezar", "venir", "verter"] 
ei = set(ei)
